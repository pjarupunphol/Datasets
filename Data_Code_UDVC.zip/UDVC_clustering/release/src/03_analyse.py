import json, numpy as np, pandas as pd
from scipy import stats
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import (adjusted_rand_score, silhouette_score, accuracy_score,
                             f1_score, confusion_matrix)
from sklearn.inspection import permutation_importance
from scipy.optimize import linear_sum_assignment

B, RS = 200, 42
feat = pd.read_csv('outputs/matrix_570x126.csv', index_col=0)
blocks = json.load(open('outputs/blocks.json'))
cols = list(feat.columns)
Z, ZW = np.load('outputs/Z.npy'), np.load('outputs/ZW.npy')
lab = np.load('outputs/labels_selected.npy')
prog = pd.read_csv('outputs/program.csv', index_col=0).prog.astype(str)
out = {}

# orient: cluster 0 = lower achievement
wg = feat['Overall_wgpa'].values
low = 0 if wg[lab == 0].mean() < wg[lab == 1].mean() else 1
lab = (lab != low).astype(int)          # 0 = low/variable, 1 = high/stable
out['sizes'] = {'low': int((lab == 0).sum()), 'high': int((lab == 1).sum()),
                'low_pct': round(100 * (lab == 0).mean(), 1)}
out['silhouette'] = round(float(silhouette_score(ZW, lab)), 3)

# ---------- 1. stability ----------
rng = np.random.default_rng(RS)
boot_idx = [rng.integers(0, 570, 570) for _ in range(B)]
aris_w, aris_u, jac, cshift, minprop = [], [], [], [], []
consist = np.zeros(570); seen = np.zeros(570)
base_cent = np.vstack([ZW[lab == c].mean(0) for c in (0, 1)])
for bi in boot_idx:
    lw = KMeans(2, n_init=10, random_state=0).fit_predict(ZW[bi])
    lu = KMeans(2, n_init=10, random_state=0).fit_predict(Z[bi])
    aris_w.append(adjusted_rand_score(lab[bi], lw))
    aris_u.append(adjusted_rand_score(lab[bi], lu))
    cent = np.vstack([ZW[bi][lw == c].mean(0) for c in (0, 1)])
    D = np.linalg.norm(base_cent[:, None] - cent[None], axis=2)
    r, cc = linear_sum_assignment(D)
    cshift.append(float(D[r, cc].mean()))
    mapping = {cc[i]: r[i] for i in range(2)}
    mapped = np.array([mapping[v] for v in lw])
    js = []
    for c in (0, 1):
        a, b = set(np.where(lab[bi] == c)[0]), set(np.where(mapped == c)[0])
        js.append(len(a & b) / max(len(a | b), 1))
    jac.append(float(np.mean(js)))
    minprop.append(float(min(np.bincount(mapped)) / len(mapped)))
    for pos, orig in enumerate(bi):
        seen[orig] += 1
        consist[orig] += (mapped[pos] == lab[orig])
q = np.where(seen > 0, consist / np.maximum(seen, 1), np.nan)
out['stability'] = dict(
    seed_ari_mean=1.0, boot_ari_mean=round(float(np.mean(aris_w)), 3),
    boot_ari_sd=round(float(np.std(aris_w, ddof=1)), 3),
    boot_ari_median=round(float(np.median(aris_w)), 3),
    jaccard=round(float(np.mean(jac)), 3), centroid_shift=round(float(np.mean(cshift)), 3),
    minority_prop_sd=round(float(np.std(minprop, ddof=1)), 3),
    q_mean=round(float(np.nanmean(q)), 3), q_median=round(float(np.nanmedian(q)), 3),
    q_min=round(float(np.nanmin(q)), 3),
    q_quartiles=[round(float(np.nanpercentile(q, p)), 3) for p in (25, 50, 75)],
    n_q_below_080=int(np.nansum(q < 0.80)),
    pct_q_below_080=round(100 * float(np.nansum(q < 0.80)) / 570, 1))
np.save('outputs/q_vector.npy', q)

# ---------- 2. weighting effect (paired, same resamples) ----------
W = stats.wilcoxon(aris_w, aris_u)
d = np.array(aris_w) - np.array(aris_u); nz = d[d != 0]
rk = stats.rankdata(abs(nz))
rb = (rk[nz > 0].sum() - rk[nz < 0].sum()) / rk.sum()
sil_w, sil_u = [], []
for bi in boot_idx:
    lw = KMeans(2, n_init=10, random_state=0).fit_predict(ZW[bi])
    lu = KMeans(2, n_init=10, random_state=0).fit_predict(Z[bi])
    sil_w.append(silhouette_score(ZW[bi], lw)); sil_u.append(silhouette_score(Z[bi], lu))
Ws = stats.wilcoxon(sil_w, sil_u)
ds = np.array(sil_w) - np.array(sil_u); nzs = ds[ds != 0]; rks = stats.rankdata(abs(nzs))
rbs = (rks[nzs > 0].sum() - rks[nzs < 0].sum()) / rks.sum()
out['weighting'] = dict(
    ari_weighted=round(float(np.mean(aris_w)), 3), ari_unweighted=round(float(np.mean(aris_u)), 3),
    ari_p=float(W.pvalue), ari_rank_biserial=round(float(rb), 3),
    sil_weighted=round(float(np.mean(sil_w)), 3), sil_unweighted=round(float(np.mean(sil_u)), 3),
    sil_gain=round(float(np.mean(sil_w) - np.mean(sil_u)), 3),
    sil_p=float(Ws.pvalue), sil_rank_biserial=round(float(rbs), 3))

# ---------- 3. profile contrasts ----------
def contrast(col):
    a, b = feat[col].values[lab == 0], feat[col].values[lab == 1]
    diff = a.mean() - b.mean()
    r = np.random.default_rng(RS)
    bs = [r.choice(a, len(a)).mean() - r.choice(b, len(b)).mean() for _ in range(5000)]
    U = stats.mannwhitneyu(a, b, alternative='two-sided')
    rb = 2 * U.statistic / (len(a) * len(b)) - 1
    return dict(low=round(float(a.mean()), 3), high=round(float(b.mean()), 3),
                diff=round(float(diff), 3),
                ci=[round(float(np.percentile(bs, 2.5)), 3), round(float(np.percentile(bs, 97.5)), 3)],
                rb=round(float(rb), 3))


PROFILE = {'Life Skills GPA': 'Life_GPA_inst', 'Basic Skills GPA': 'Basic_GPA_inst',
           'Specific Skills GPA': 'Specific_GPA_inst', 'Overall weighted GPA': 'Overall_wgpa',
           'Overall grade SD': 'Overall_sd_grade', 'Overall low-grade count': 'Overall_low_count',
           'Term-level GPA SD': 'T_gpa_sd', 'Overall failed-course count': 'Overall_fail_count',
           'GPA change first to last term': 'T_gpa_change', 'Temporal GPA slope': 'T_slope'}
out['profiles'] = {k: contrast(v) for k, v in PROFILE.items()}

# ---------- 4. surrogate ----------
Xtr, Xte, ytr, yte = train_test_split(Z, lab, test_size=0.3, random_state=RS, stratify=lab)
sur = LogisticRegression(max_iter=5000).fit(Xtr, ytr)
pred = sur.predict(Xte)
cm = confusion_matrix(yte, pred)
pi = permutation_importance(sur, Xte, yte, n_repeats=200, random_state=RS, scoring='accuracy')
imp = pd.DataFrame({'feature': cols, 'drop': pi.importances_mean, 'sd': pi.importances_std,
                    'beta_low': -sur.coef_[0]}).sort_values('drop', ascending=False)
out['surrogate'] = dict(n_train=len(ytr), n_test=len(yte),
                        accuracy=round(float(accuracy_score(yte, pred)), 4),
                        macro_f1=round(float(f1_score(yte, pred, average='macro')), 4),
                        confusion=cm.tolist(),
                        top=imp.head(8).round(4).to_dict('records'))
imp.to_csv('outputs/permutation_importance.csv', index=False)

# ---------- 5. transparent baselines ----------
def baseline(name, X):
    l2 = KMeans(2, n_init=10, random_state=0).fit_predict(X)
    a = []
    for bi in boot_idx:
        a.append(adjusted_rand_score(l2[bi],
                 KMeans(2, n_init=10, random_state=0).fit_predict(X[bi])))
    return dict(name=name, n_features=X.shape[1],
                ari_vs_full=round(float(adjusted_rand_score(lab, l2)), 3),
                silhouette=round(float(silhouette_score(X, l2)), 3),
                boot_ari=round(float(np.mean(a)), 3),
                sizes=sorted(np.bincount(l2).tolist()))


S = lambda names: StandardScaler().fit_transform(feat[names].values)
BASE = [
    ('Overall weighted GPA only', ['Overall_wgpa']),
    ('Three competency GPAs', ['Life_GPA_inst', 'Basic_GPA_inst', 'Specific_GPA_inst']),
    ('Low-grade and failure counts', ['Overall_low_count', 'Overall_fail_count']),
    ('Six simple advising indicators', ['Overall_wgpa', 'Overall_sd_grade', 'Overall_low_count',
                                        'Overall_fail_count', 'T_gpa_sd', 'T_slope']),
    ('Competency GPAs + low/fail', ['Life_GPA_inst', 'Basic_GPA_inst', 'Specific_GPA_inst',
                                    'Overall_low_count', 'Overall_fail_count']),
]
out['baselines'] = [baseline(n, S(c)) for n, c in BASE]

# ---------- 6. redundancy ----------
C = np.corrcoef(Z.T)
absC = np.abs(C - np.eye(126))
sv = np.linalg.svd(Z, compute_uv=False)
out['redundancy'] = dict(
    pairs_r_above_090=int((np.triu(absC, 1) > 0.90).sum()),
    pairs_r_above_080=int((np.triu(absC, 1) > 0.80).sum()),
    mean_abs_r=round(float(np.triu(absC, 1)[np.triu(absC, 1) > 0].mean()), 3),
    rank=int(np.linalg.matrix_rank(Z)),
    condition_number=round(float(sv[0] / sv[sv > 1e-10][-1]), 1),
    pcs_for_90pct_variance=int(np.searchsorted(np.cumsum(sv**2) / (sv**2).sum(), 0.90) + 1),
    pcs_for_95pct_variance=int(np.searchsorted(np.cumsum(sv**2) / (sv**2).sum(), 0.95) + 1))

# ---------- 7. program confounding ----------
pr = prog.reindex(feat.index).values
ct = pd.crosstab(pr, lab)
big = ct.sum(1) >= 20
chi = stats.chi2_contingency(ct[big.values])
n = ct[big.values].values.sum()
out['program'] = dict(
    n_programs=int(ct.shape[0]), n_programs_ge20=int(big.sum()),
    crosstab=ct.to_dict(), chi2=round(float(chi.statistic), 2), df=int(chi.dof),
    p=float(chi.pvalue),
    cramers_v=round(float(np.sqrt(chi.statistic / n)), 3),
    ari_cluster_vs_program=round(float(adjusted_rand_score(pr, lab)), 3),
    low_share_by_program={k: round(float(v), 3) for k, v in
                          (ct[0] / ct.sum(1))[big.values].items()})
gpa_groups = [feat.Overall_wgpa.values[pr == p] for p in ct.index[big.values]]
H = stats.kruskal(*gpa_groups)
out['program']['kruskal_gpa_H'] = round(float(H.statistic), 2)
out['program']['kruskal_gpa_p'] = float(H.pvalue)

# ---------- 8. coverage bias ----------
ex = pd.read_csv('outputs/excluded_ledger.csv')
def ledger_summary(df):
    g = df.groupby('Psudo_Student_ID')
    return pd.DataFrame({
        'wgpa': g.apply(lambda d: np.average(d.Grade, weights=d.Credit), include_groups=False),
        'low': g.apply(lambda d: int((d.Grade < 2).sum()), include_groups=False),
        'fail': g.apply(lambda d: int((d.Grade == 0).sum()), include_groups=False),
        'terms': g.Term.nunique(), 'credits': g.Credit.sum()})
E = ledger_summary(ex)
I = feat[['Overall_wgpa', 'Overall_low_count', 'Overall_fail_count', 'T_terms', 'Overall_credits']]
I.columns = ['wgpa', 'low', 'fail', 'terms', 'credits']
cov = {}
for c in I.columns:
    a, b = I[c].values, E[c].values
    U = stats.mannwhitneyu(a, b, alternative='two-sided')
    cov[c] = dict(included=round(float(a.mean()), 3), excluded=round(float(b.mean()), 3),
                  rb=round(float(2 * U.statistic / (len(a) * len(b)) - 1), 3))
out['coverage_bias'] = cov

json.dump(out, open('outputs/results_full.json', 'w'), indent=2, default=str)
print(json.dumps(out, indent=2, default=str)[:6000])
