"""Regenerate the engineered 570 x 126 matrix from the ledger and competency files."""
import numpy as np, pandas as pd, json, hashlib

COMP = 'data/competency_indicators.csv'
LED = 'data/course_ledger.csv'
TERM_ORDER = ['1/2567', '2/2567', '3/2567', '1/2568', '2/2568']
LOW, FAIL = 2.00, 0.00


def wmean(g, v='Grade', w='Credit'):
    cw = g[w].sum()
    return np.average(g[v], weights=g[w]) if cw > 0 else np.nan


comp = pd.read_csv(COMP)
led = pd.read_csv(LED)
comp = comp.rename(columns={'student_id': 'Psudo_Student_ID'})
led = led.rename(columns={'student_id': 'Psudo_Student_ID', 'term': 'Term',
                          'course_code': 'Course_Code', 'course_name': 'Course_Name',
                          'credit': 'Credit', 'grade': 'Grade'})
comp['prog'] = comp.program
led['prefix'] = led.Course_Code.astype(str).str[:5]
led['domain'] = np.where(led.prefix == '30000', 'Life',
                np.where(led.prefix == '30001', 'Basic', 'Specific'))
led['term_idx'] = led.Term.map({t: i for i, t in enumerate(TERM_ORDER)})

analytic = comp.Psudo_Student_ID.tolist()
sub = led[led.Psudo_Student_ID.isin(analytic)].copy()
print('analytical students', len(analytic), '| ledger rows used', len(sub))

feat = pd.DataFrame(index=pd.Index(analytic, name='sid'))
blocks = {}

# ---------- institutional GPAs ----------
c = comp.set_index('Psudo_Student_ID')
feat['Life_GPA_inst'] = c.Life_Skills_GPA
feat['Basic_GPA_inst'] = c.Basic_Skills_GPA
feat['Specific_GPA_inst'] = c.Specific_Skills_GPA


def ledger_block(df, tag):
    """10 ledger indicators for a set of records."""
    out = {}
    g = df.groupby('Psudo_Student_ID')
    out[f'{tag}_records'] = g.size()
    out[f'{tag}_credits'] = g.Credit.sum()
    out[f'{tag}_mean_grade'] = g.Grade.mean()
    out[f'{tag}_wgpa'] = g.apply(wmean, include_groups=False)
    out[f'{tag}_min_grade'] = g.Grade.min()
    out[f'{tag}_max_grade'] = g.Grade.max()
    out[f'{tag}_sd_grade'] = g.Grade.std()
    out[f'{tag}_low_count'] = g.apply(lambda d: int((d.Grade < LOW).sum()), include_groups=False)
    out[f'{tag}_fail_count'] = g.apply(lambda d: int((d.Grade == FAIL).sum()), include_groups=False)
    out[f'{tag}_low_rate'] = g.apply(lambda d: float((d.Grade < LOW).mean()), include_groups=False)
    return pd.DataFrame(out)


# ---------- three competency blocks (1 GPA + 10 ledger = 11 each) ----------
for dom, gpa in [('Life', 'Life_GPA_inst'), ('Basic', 'Basic_GPA_inst'),
                 ('Specific', 'Specific_GPA_inst')]:
    b = ledger_block(sub[sub.domain == dom], dom)
    feat = feat.join(b)
    blocks[dom] = [gpa] + list(b.columns)

# ---------- temporal block (10) ----------
term = sub.groupby(['Psudo_Student_ID', 'term_idx']).apply(
    lambda d: pd.Series({'gpa': wmean(d), 'credits': d.Credit.sum(),
                         'low': int((d.Grade < LOW).sum()),
                         'fail': int((d.Grade == FAIL).sum())}), include_groups=False
).reset_index()


def temporal(d):
    d = d.sort_values('term_idx')
    x, y = d.term_idx.values.astype(float), d.gpa.values
    slope = np.polyfit(x, y, 1)[0] if len(d) > 1 and np.ptp(x) > 0 else 0.0
    return pd.Series({
        'T_terms': len(d), 'T_first_gpa': y[0], 'T_last_gpa': y[-1],
        'T_gpa_change': y[-1] - y[0], 'T_slope': slope,
        'T_gpa_sd': np.std(y, ddof=1) if len(d) > 1 else 0.0,
        'T_mean_credits': d.credits.mean(),
        'T_sd_credits': d.credits.std(ddof=1) if len(d) > 1 else 0.0,
        'T_low_terms': int((d.low > 0).sum()), 'T_failed_terms': int((d.fail > 0).sum())})


tb = term.groupby('Psudo_Student_ID').apply(temporal, include_groups=False)
feat = feat.join(tb)
blocks['Temporal'] = list(tb.columns)

# ---------- overall block (11) ----------
ob = ledger_block(sub, 'Overall')
ob.insert(1, 'Overall_unique_courses', sub.groupby('Psudo_Student_ID').Course_Code.nunique())
feat = feat.join(ob)

# ---------- course-prefix block (3 x 24 = 72) ----------
prefixes = sorted(sub.prefix.unique())
assert len(prefixes) == 24, len(prefixes)
pf = {}
for p in prefixes:
    d = sub[sub.prefix == p]
    g = d.groupby('Psudo_Student_ID')
    pf[f'P{p}_records'] = g.size()
    pf[f'P{p}_credits'] = g.Credit.sum()
    pf[f'P{p}_wgpa'] = g.apply(wmean, include_groups=False)
pfd = pd.DataFrame(pf).reindex(feat.index).fillna(0.0)
feat = feat.join(pfd)
blocks['OverallPrefix'] = list(ob.columns) + list(pfd.columns)

feat = feat.fillna(0.0)
sizes = {k: len(v) for k, v in blocks.items()}
print('block sizes', sizes, 'total', sum(sizes.values()), '| matrix', feat.shape)
assert feat.shape == (570, 126), feat.shape
assert sum(sizes.values()) == 126

feat.to_csv('outputs/matrix_570x126.csv')
json.dump({k: list(v) for k, v in blocks.items()}, open('outputs/blocks.json', 'w'), indent=1)
comp.set_index('Psudo_Student_ID')[['prog']].to_csv('outputs/program.csv')

# excluded students, for the coverage-bias analysis
excl = led[~led.Psudo_Student_ID.isin(analytic)]
print('excluded students', excl.Psudo_Student_ID.nunique())
excl.to_csv('outputs/excluded_ledger.csv', index=False)
print('sha256', hashlib.sha256(open('outputs/matrix_570x126.csv','rb').read()).hexdigest()[:16])
