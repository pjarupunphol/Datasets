"""28-candidate comparison, composite scoring, and stability of the selected solution."""
import json, numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.mixture import GaussianMixture
from sklearn.metrics import (silhouette_score, davies_bouldin_score,
                             calinski_harabasz_score, adjusted_rand_score)

SEEDS = list(range(8))
B = 200
rng_global = np.random.default_rng(42)

feat = pd.read_csv('outputs/matrix_570x126.csv', index_col=0)
blocks = json.load(open('outputs/blocks.json'))
cols = list(feat.columns)
Z = StandardScaler().fit_transform(feat.values)

# inverse-square-root block scaling
w = np.ones(len(cols))
for b, members in blocks.items():
    idx = [cols.index(m) for m in members]
    w[idx] = 1 / np.sqrt(len(members))
ZW = Z * w
print('scaling factors', {b: round(1 / np.sqrt(len(m)), 4) for b, m in blocks.items()})


def fit(method, k, X, seed=0):
    if method == 'Standard k-means':
        return KMeans(k, n_init=10, random_state=seed).fit_predict(X)
    if method == 'Block-weighted k-means':
        return KMeans(k, n_init=10, random_state=seed).fit_predict(X)
    if method == 'Ward clustering':
        return AgglomerativeClustering(n_clusters=k, linkage='ward').fit_predict(X)
    if method == 'Diagonal Gaussian mixture':
        return GaussianMixture(k, covariance_type='diag', n_init=3,
                               random_state=seed).fit_predict(X)


METHODS = {'Standard k-means': Z, 'Block-weighted k-means': ZW,
           'Ward clustering': ZW, 'Diagonal Gaussian mixture': ZW}
STOCH = {'Standard k-means', 'Block-weighted k-means', 'Diagonal Gaussian mixture'}

boot_idx = [rng_global.integers(0, 570, 570) for _ in range(B)]

rows = []
labels_store = {}
for method, X in METHODS.items():
    for k in range(2, 9):
        lab = fit(method, k, X, seed=0)
        labels_store[(method, k)] = lab
        sil = silhouette_score(X, lab)
        db = davies_bouldin_score(X, lab)
        ch = calinski_harabasz_score(X, lab)
        sizes = np.bincount(lab)
        minprop = sizes.min() / len(lab)

        if method in STOCH:
            ls = [fit(method, k, X, seed=s) for s in SEEDS]
            seed_ari = np.mean([adjusted_rand_score(ls[i], ls[j])
                                for i in range(len(ls)) for j in range(i + 1, len(ls))])
            seed_sd = np.std([adjusted_rand_score(ls[i], ls[j])
                              for i in range(len(ls)) for j in range(i + 1, len(ls))], ddof=1)
        else:
            seed_ari, seed_sd = np.nan, np.nan

        aris = []
        for bi in boot_idx:
            lb = fit(method, k, X[bi], seed=0)
            aris.append(adjusted_rand_score(lab[bi], lb))
        rows.append(dict(method=method, k=k, sil=sil, db=db, ch=ch,
                         sizes='/'.join(map(str, sorted(sizes))), minprop=minprop,
                         seed_ari=seed_ari, seed_sd=seed_sd,
                         boot_ari=np.mean(aris), boot_sd=np.std(aris, ddof=1),
                         boot_med=np.median(aris)))
    print(method, 'done', flush=True)

d = pd.DataFrame(rows)


def mm(s, reverse=False):
    v = -s if reverse else s
    return (v - v.min()) / (v.max() - v.min())


d['score'] = (0.30 * mm(d.sil) + 0.20 * mm(d.db, reverse=True) + 0.20 * mm(d.ch)
              + 0.20 * mm(d.boot_ari) + 0.10 * mm(d.minprop))
d = d.sort_values('score', ascending=False).reset_index(drop=True)
d.to_csv('outputs/candidates_28.csv', index=False)
print(d.head(8).round(3).to_string(index=False))

sel = d.iloc[0]
print('\nSELECTED:', sel.method, 'k =', sel.k)
np.save('outputs/labels_selected.npy', labels_store[(sel.method, int(sel.k))])
np.save('outputs/ZW.npy', ZW)
np.save('outputs/Z.npy', Z)
json.dump(dict(method=sel.method, k=int(sel.k)), open('outputs/selected.json', 'w'))
