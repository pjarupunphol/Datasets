# Stability-aware block-weighted clustering of vocational student competency profiles

Data and analysis code for the manuscript *Stability-Aware Block-Weighted Clustering of
Vocational Student Competency Profiles*.

Running the three scripts in order reproduces every quantitative result reported in the
paper: the engineered feature matrix, the 28-candidate comparison, the composite ranking,
the bootstrap stability analysis, the profile contrasts, the surrogate model, the
transparent baselines, the redundancy audit, the program cross-tabulation, and the
coverage-bias comparison.

## Contents

```
data/
  competency_indicators.csv    570 students; institutional competency GPAs and program label
  course_ledger.csv            18,727 student-course records across five terms
src/
  01_build_matrix.py           builds the 570 x 126 engineered matrix
  02_run_candidates.py         28 candidates, composite score, selects the solution
  03_analyse.py                stability, weighting, profiles, surrogate, baselines,
                               redundancy, program confounding, coverage bias
outputs/                       created on first run
requirements.txt
```

## Reproducing the results

```bash
pip install -r requirements.txt
cd <repository root>
mkdir -p outputs
python src/01_build_matrix.py
python src/02_run_candidates.py
python src/03_analyse.py
```

Total runtime is roughly 30 minutes on a single CPU core; step 3 dominates, because it
refits both the weighted and unweighted solutions on 200 bootstrap resamples and runs
5,000-iteration bootstrap confidence intervals for the profile contrasts.

Results are written to `outputs/`:

| File | Contents |
|---|---|
| `matrix_570x126.csv` | engineered feature matrix |
| `blocks.json` | block membership for the five feature blocks |
| `candidates_28.csv` | all 28 candidates with internal indices, stability, composite score |
| `results_full.json` | every statistic reported in Sections 4.1 to 4.8 |
| `permutation_importance.csv` | surrogate permutation importance, all 126 features |
| `q_vector.npy` | per-student assignment consistency |

## Determinism

Random seeds are fixed throughout: seed 0 for k-means initialisation, seed 42 for the
bootstrap index sets and the surrogate train/test split, and seeds 0 to 7 for the
initialisation-stability check. Results depend on the row order of the input files, which
must be preserved. Reruns on the same package reproduce the reported values exactly.

Two figures in the paper are sensitive to library version: Silhouette and
Calinski-Harabasz values can shift in the third decimal place across scikit-learn
releases. The pinned versions in `requirements.txt` are those used for the reported
results.

## De-identification

These files are **not** the pseudonymised files circulated with the original submission.
Those used a base-8 transcription of institutional student numbers, which is reversible
and therefore not an adequate de-identification. This release replaces them.

- Student identifiers are random surrogate labels (`S0001` to `S0654`) drawn from a
  permutation with no relationship to any institutional number. The mapping is not
  distributed.
- Study program is released as an opaque label (`P01` to `P16`) rather than the
  institutional program code, so the program-confounding analysis in Section 4.4 remains
  reproducible without exposing the coding scheme.
- No names, national identity numbers, dates of birth, or contact information appear in
  any file, and none were available to the research team.

Records remain individually distinct, and course-enrolment patterns combined with grades
could in principle support re-identification by someone with access to internal
enrolment records. Release of this package was reviewed and approved by Udon Thani
Vocational College. Users must not attempt re-identification or link these records to any
other source.

## Data dictionary

`competency_indicators.csv`

| Column | Description |
|---|---|
| `student_id` | surrogate identifier |
| `program` | opaque program label |
| `Life_Skills_GPA`, `Basic_Skills_GPA`, `Specific_Skills_GPA` | institutional competency GPAs, 0-4 scale |

`course_ledger.csv`

| Column | Description |
|---|---|
| `student_id` | surrogate identifier, links to the competency file |
| `term` | academic term, Thai Buddhist calendar (`1/2567` = semester 1, 2024) |
| `course_code` | institutional course code; first five digits give the course prefix |
| `course_name` | course title |
| `credit` | credit value |
| `grade` | 0-4 grade point |

Competency domains are defined by course prefix: `30000` = Life Skills, `30001` = Basic
Skills, all other prefixes = Specific Skills. The analytical sample is the 570 students
present in both files; 84 ledger-only students are excluded and used for the
coverage-bias comparison in Section 4.7.

## Citation

Kultangwattana, W., Somkantha, K., Khamsittiban, T., & Jarupunphol, P. Stability-aware
block-weighted clustering of vocational student competency profiles. *(under review)*

## Licence

Code released under the MIT Licence. Data released under CC BY-NC 4.0 for
non-commercial research use.
