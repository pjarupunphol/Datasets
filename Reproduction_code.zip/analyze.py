"""Step 2: all analyses on frozen data. Usage: python -I analyze.py out"""
import sys, json, numpy as np, pandas as pd
from scipy.spatial.distance import jensenshannon
out = sys.argv[1]; T = f"{out}/tables"; rng = np.random.default_rng(20261009); B = 1000
P = pd.read_csv(f"{out}/data_primary.csv")
M = {}  # result manifest
CATCH = ['Other industries', 'Central administration']
short = {'Agriculture, forestry, fisheries and veterinary':'Agriculture','Arts and humanities':'Arts & humanities',
 'Business, administration and law':'Business, admin. & law','Education':'Education',
 'Engineering, manufacturing and construction':'Engineering','Health and welfare':'Health & welfare','ICTs':'ICTs',
 'Natural sciences, mathematics and statistics':'Natural sciences','Services':'Services',
 'Social sciences, journalism and information':'Social sciences','Tourism, Hospitality, Travel, Services, Recreation':'Tourism & hospitality'}
P['fs'] = P.field.map(short); assert P.fs.notna().all()

def hill(c):
    p = c[c>0]/c.sum(); H = -(p*np.log(p)).sum()
    return np.exp(H), 1/(p**2).sum(), H
def boot_hill(c):
    c = np.asarray(c); n = c.sum(); p = c/n
    s = rng.multinomial(n, p, size=B)
    d1 = []; d2 = []
    for r in s:
        a, b, _ = hill(r); d1.append(a); d2.append(b)
    return np.percentile(d1,[2.5,97.5]), np.percentile(d2,[2.5,97.5])
def cr(c,k): c=np.sort(np.asarray(c))[::-1]; return c[:k].sum()/c.sum()

# ---- Descriptives
N = P.n.sum(); M['N_graduates']=int(N); M['N_cells']=len(P); M['N_industries']=P.industry.nunique()
desc_f = P.groupby('fs').n.sum().sort_values(ascending=False)
yr = P.pivot_table(index='fs',columns='year',values='n',aggfunc='sum')
deg = P.pivot_table(index='fs',columns='degree',values='n',aggfunc='sum')[['Bachelor','Master','Doctorate']]
t1 = pd.DataFrame({'Graduates':desc_f,'Share_%':(desc_f/N*100).round(1)}).join(deg).join(yr)
t1['Change_2022_2023_%'] = ((t1[2023]/t1[2022]-1)*100).round(1)
t1['Industries_entered'] = P.groupby('fs').industry.nunique()
t1.loc['Total'] = t1.sum(numeric_only=True); t1.loc['Total','Share_%']=100.0
t1.loc['Total','Change_2022_2023_%']=round((t1.loc['Total',2023]/t1.loc['Total',2022]-1)*100,1)
t1.loc['Total','Industries_entered']=P.industry.nunique()
t1.to_csv(f"{T}/T1_descriptives.csv")
M['year_totals']=P.groupby('year').n.sum().astype(int).to_dict()
M['degree_totals']=P.groupby('degree').n.sum().astype(int).to_dict()
M['field_change_2022_2023_range']=[float(t1.drop('Total')['Change_2022_2023_%'].min()), float(t1.drop('Total')['Change_2022_2023_%'].max())]

# ---- RQ1 Field-side dispersion
FI = P.groupby(['fs','industry']).n.sum().unstack(fill_value=0)
rows=[]
for f, c in FI.iterrows():
    c=c[c>0]; d1,d2,H = hill(c.values); ci1,ci2 = boot_hill(c.values)
    top = c.sort_values(ascending=False)
    rows.append({'Field':f,'Graduates':int(c.sum()),'Industries':len(c),'D1':d1,'D1_lo':ci1[0],'D1_hi':ci1[1],
      'D2':d2,'D2_lo':ci2[0],'D2_hi':ci2[1],'CR1':cr(c,1),'CR5':cr(c,5),'CatchAll_share':c.reindex(CATCH).fillna(0).sum()/c.sum(),
      'Top_industry':top.index[0],'Top_share':top.iloc[0]/c.sum(),
      'Top_noncatch':top.drop(CATCH,errors='ignore').index[0],'Top_noncatch_share':top.drop(CATCH,errors='ignore').iloc[0]/c.sum()})
t2 = pd.DataFrame(rows).sort_values('D1'); t2.to_csv(f"{T}/T2_field_dispersion.csv",index=False)
M['D1_range']=[t2.D1.min(),t2.D1.max()]; M['CatchAll_overall']=float(P[P.industry.isin(CATCH)].n.sum()/N)

# dispersion excluding catch-all and by degree
rows=[]
for (f,dg), g in P.groupby(['fs','degree']):
    c=g.groupby('industry').n.sum(); d1,d2,_=hill(c.values)
    cx=c.drop(CATCH,errors='ignore'); e1,e2,_=hill(cx.values)
    rows.append({'Field':f,'Degree':dg,'Graduates':int(c.sum()),'D1':d1,'D2':d2,'D1_excl_catchall':e1,'CatchAll_share':1-cx.sum()/c.sum()})
t2b = pd.DataFrame(rows); t2b.to_csv(f"{T}/T2b_dispersion_by_degree.csv",index=False)
ex=[]
for f,c in FI.iterrows():
    cx=c.drop(CATCH)[lambda s:s>0]; ex.append({'Field':f,'D1_excl_catchall':hill(cx.values)[0]})
ex=pd.DataFrame(ex).set_index('Field'); t2=t2.set_index('Field').join(ex).reset_index(); t2.to_csv(f"{T}/T2_field_dispersion.csv",index=False)
from scipy.stats import spearmanr
M['rank_corr_D1_vs_D1_excl_catchall']=spearmanr(t2.D1,t2.D1_excl_catchall)[0]
M['rank_corr_D1_vs_D2']=spearmanr(t2.D1,t2.D2)[0]
# degree gradient summary (pooled across fields)
dg_pool = {dg: hill(P[P.degree==dg].groupby('industry').n.sum().values)[0] for dg in ['Bachelor','Master','Doctorate']}
M['D1_pooled_by_degree']=dg_pool

# ---- RQ2 Industry-side recruitment breadth
IF = FI.T; IF = IF[IF.sum(1)>=30]
rows=[]
for i,c in IF.iterrows():
    d1,d2,_=hill(c[c>0].values); rows.append({'Industry':i,'Graduates':int(c.sum()),'Fields_present':int((c>0).sum()),'D1_fields':d1,
      'Dominant_field':c.idxmax(),'Dominant_share':c.max()/c.sum()})
t3=pd.DataFrame(rows); t3.to_csv(f"{T}/T3_industry_breadth_all.csv",index=False)
M['industries_ge30']=len(t3); M['industries_all11_fields_share']=float((t3.Fields_present==11).mean())
M['industry_D1_quartiles']=t3.D1_fields.quantile([.25,.5,.75]).round(2).tolist()
M['industries_dominant_ge50']=int((t3.Dominant_share>=.5).sum()); M['industries_dominant_ge80']=int((t3.Dominant_share>=.8).sum())
M['grads_in_ind_dominant_ge50']=float(t3[t3.Dominant_share>=.5].Graduates.sum()/t3.Graduates.sum())
t3.sort_values('Dominant_share',ascending=False).head(15).to_csv(f"{T}/T3a_most_specialised.csv",index=False)
t3.sort_values('Graduates',ascending=False).head(15).to_csv(f"{T}/T3b_largest.csv",index=False)
# naive presence-based ambiguity (MS2 metric) for contrast
pres=(FI>0).sum(); M['presence_mean_fields_per_industry']=float(pres.mean()); M['presence_all11']=int((pres==11).sum())

# ---- RQ3 Location quotients: signature industries
Nf=FI.sum(1); Ni=FI.sum(0)
LQ=(FI.div(Ni,axis=1)).div(Nf/N,axis=0)
sig=[]
for f in FI.index:
    s=pd.DataFrame({'n':FI.loc[f],'LQ':LQ.loc[f],'share_of_field':FI.loc[f]/Nf[f]})
    s=s[(s.n>=30)].sort_values('n',ascending=False); s=s[s.LQ>=2]
    for i,r in s.head(4).iterrows(): sig.append({'Field':f,'Industry':i,'Graduates':int(r.n),'Share_of_field':r.share_of_field,'LQ':r.LQ})
    M[f'signature_share_{f}']=float(s.n.sum()/Nf[f])
t4=pd.DataFrame(sig); t4.to_csv(f"{T}/T4_signature_industries.csv",index=False)
sigshare=pd.Series({f:M[f'signature_share_{f}'] for f in FI.index}); sigshare.to_csv(f"{T}/T4b_signature_share.csv")

# ---- RQ4 Identifiability of field from industry label (information-theoretic bound)
def ident(tab):
    n=tab.values; Ntot=n.sum(); pf=n.sum(1)/Ntot; pi=n.sum(0)/Ntot
    Hf=-(pf[pf>0]*np.log(pf[pf>0])).sum()
    pj=n/Ntot; nz=pj>0
    I=(pj[nz]*np.log(pj[nz]/np.outer(pf,pi)[nz])).sum()
    bayes=n.max(0).sum()/Ntot; base=pf.max()
    # macro-F1 of Bayes (dominant-field) rule, graduate-weighted
    pred=np.argmax(n,0); f1=[]
    for k in range(n.shape[0]):
        tp=n[k,pred==k].sum(); fp=n[:,pred==k].sum()-tp; fn=n[k].sum()-tp
        f1.append(0 if tp==0 else 2*tp/(2*tp+fp+fn))
    return dict(U=I/Hf, MI_nats=I, H_field=Hf, bayes_acc=bayes, majority_acc=base, bayes_macroF1=float(np.mean(f1)), fields_ever_predicted=int(len(set(pred))))
idt={}
idt['pooled']=ident(FI)
for dg in ['Bachelor','Master','Doctorate']: idt[dg]=ident(P[P.degree==dg].groupby(['fs','industry']).n.sum().unstack(fill_value=0))
idt['excl_catchall']=ident(FI.drop(columns=CATCH))
# industry x degree as predictor
P['ind_deg']=P.industry+'|'+P.degree
idt['industry_plus_degree']=ident(P.groupby(['fs','ind_deg']).n.sum().unstack(fill_value=0))
# row-weighted (cells, as in a text classifier trained on rows)
cnt=P.groupby(['fs','industry']).size().unstack(fill_value=0); idt['row_weighted']=ident(cnt)
t5=pd.DataFrame(idt).T; t5.to_csv(f"{T}/T5_identifiability.csv"); M['identifiability']=t5.round(4).to_dict('index')

# Empirical text-classifier benchmark (replicates MS2 design, graduate-weighted evaluation)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GroupKFold
from sklearn.metrics import f1_score, accuracy_score
X=P.industry.values; y=P.fs.values; w=P.n.values; g=P.industry.values
oof=np.empty(len(P),dtype=object)
for tr,te in GroupKFold(5).split(X,y,g):
    v=TfidfVectorizer(ngram_range=(1,2),min_df=2,sublinear_tf=True); Xtr=v.fit_transform(X[tr])
    m=LogisticRegression(max_iter=2000,class_weight='balanced',C=1.0).fit(Xtr,y[tr],sample_weight=w[tr]/w[tr].mean())
    oof[te]=m.predict(v.transform(X[te]))
M['text_clf']={'acc_grad_weighted':accuracy_score(y,oof,sample_weight=w),'macroF1_grad_weighted':f1_score(y,oof,average='macro',sample_weight=w),
               'acc_row':accuracy_score(y,oof),'macroF1_row':f1_score(y,oof,average='macro')}

# ---- RQ5 Temporal stability (JSD) with sampling null
rows=[]
for f in FI.index:
    g=P[P.fs==f].pivot_table(index='industry',columns='year',values='n',aggfunc='sum',fill_value=0)
    for a,b in [(2021,2022),(2022,2023),(2021,2023)]:
        obs=jensenshannon(g[a],g[b],base=2)**2
        # null: both years drawn from pooled distribution with their own sizes
        pp=(g[a]+g[b])/(g[a]+g[b]).sum(); nul=[]
        for _ in range(200):
            nul.append(jensenshannon(rng.multinomial(g[a].sum(),pp),rng.multinomial(g[b].sum(),pp),base=2)**2)
        rows.append({'Field':f,'Pair':f"{a}-{b}",'JSD':obs,'Null_mean':np.mean(nul),'Null_p95':np.percentile(nul,95),'Ratio_to_null':obs/np.mean(nul)})
t6=pd.DataFrame(rows); t6.to_csv(f"{T}/T6_stability.csv",index=False)
pv=t6.pivot(index='Field',columns='Pair',values='JSD'); M['JSD_median_by_pair']=t6.groupby('Pair').JSD.median().round(4).to_dict()
M['JSD_ratio_median_by_pair']=t6.groupby('Pair').Ratio_to_null.median().round(2).to_dict()
M['JSD_max']=float(t6.JSD.max())
# D1 by year rank stability
d1y=pd.DataFrame({y_:{f:hill(P[(P.fs==f)&(P.year==y_)].groupby('industry').n.sum().values)[0] for f in FI.index} for y_ in [2021,2022,2023]})
d1y.to_csv(f"{T}/T6b_D1_by_year.csv"); M['D1_rank_corr_2021_2023']=spearmanr(d1y[2021],d1y[2023])[0]; M['D1_rank_corr_2022_2023']=spearmanr(d1y[2022],d1y[2023])[0]

# ---- RQ6 Field similarity (1 - JSD) of destination profiles
fs=list(FI.index); S=pd.DataFrame(index=fs,columns=fs,dtype=float)
for a in fs:
    for b in fs: S.loc[a,b]=1-jensenshannon(FI.loc[a],FI.loc[b],base=2)**2
S.to_csv(f"{T}/T7_field_similarity.csv")
Sx=pd.DataFrame(index=fs,columns=fs,dtype=float); FIx=FI.drop(columns=CATCH)
for a in fs:
    for b in fs: Sx.loc[a,b]=1-jensenshannon(FIx.loc[a],FIx.loc[b],base=2)**2
Sx.to_csv(f"{T}/T7b_field_similarity_excl_catchall.csv")
tri=S.where(np.triu(np.ones(S.shape),1).astype(bool)).stack().dropna().sort_values(ascending=False)
M['most_similar_pairs']=[(a,b,round(v,3)) for (a,b),v in tri.head(5).items()]; M['least_similar_pairs']=[(a,b,round(v,3)) for (a,b),v in tri.tail(3).items()]
trix=Sx.where(np.triu(np.ones(Sx.shape),1).astype(bool)).stack().dropna().sort_values(ascending=False)
M['most_similar_pairs_excl_catchall']=[(a,b,round(v,3)) for (a,b),v in trix.head(5).items()]

# ---- Robustness across data variants
rob=[]
for var in ['primary','dedup_then_sum','max_of_pair']:
    D=pd.read_csv(f"{out}/data_{var}.csv"); D['fs']=D.field.map(short)
    for yrs,lab in [([2021,2022,2023],'all years'),([2021,2022],'2021-2022 only')]:
        Dd=D[D.year.isin(yrs)]; tab=Dd.groupby(['fs','industry']).n.sum().unstack(fill_value=0)
        d1={f:hill(c[c>0].values)[0] for f,c in tab.iterrows()}
        r={'Variant':var,'Years':lab,'Graduates':int(Dd.n.sum()),'U':ident(tab)['U'],'Bayes_acc':ident(tab)['bayes_acc'],
           'rho_D1_vs_primary':spearmanr(pd.Series(d1)[t2.Field],t2.set_index('Field').D1)[0]}
        r.update({f'D1_{f}':v for f,v in d1.items()}); rob.append(r)
t8=pd.DataFrame(rob); t8.to_csv(f"{T}/T8_robustness.csv",index=False)
M['robustness_rho_min']=float(t8.rho_D1_vs_primary.min()); M['robustness_U_range']=[float(t8.U.min()),float(t8.U.max())]
M['robustness_bayes_range']=[float(t8.Bayes_acc.min()),float(t8.Bayes_acc.max())]

# ---- Effect of the leaked rows (original-error contrast)
raw=pd.read_excel(sys.argv[2]) if len(sys.argv)>2 else None
json.dump(M, open(f"{out}/result_manifest.json",'w'), indent=2, default=lambda o: float(o) if isinstance(o,(np.floating,np.integer)) else str(o))
print(json.dumps(M, indent=1, default=str))
