"""Step 3: figures (300 dpi, no in-figure titles, Okabe-Ito, grayscale-safe). Usage: python -I figs.py out"""
import sys, json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, leaves_list
from scipy.spatial.distance import squareform
exec(open('common.py').read())
out=sys.argv[1]; T=f"{out}/tables"; F=f"{out}/figs"; P=load(out); CATCH=['Other industries','Central administration']
OI=['#0072B2','#E69F00','#009E73','#D55E00','#CC79A7','#56B4E9','#000000']; G='#B0B0B0'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':300,'savefig.bbox':'tight'})
M=json.load(open(f"{out}/result_manifest.json")); t2=pd.read_csv(f"{T}/T2_field_dispersion.csv").sort_values('D1')

# Fig 1 dumbbell
fig,ax=plt.subplots(figsize=(6.3,3.8)); y=np.arange(len(t2))
ax.hlines(y,t2.D1,t2.D1_excl_catchall,color=G,lw=1.4,zorder=1)
ax.errorbar(t2.D1,y,xerr=[t2.D1-t2.D1_lo,t2.D1_hi-t2.D1],fmt='o',color=OI[0],ms=6,capsize=2,label='All 953 industries',zorder=3)
ax.plot(t2.D1_excl_catchall,y,'s',color=OI[3],ms=6,mfc='white',mew=1.6,label='Excluding the two catch-all categories',zorder=3)
ax.set_yticks(y); ax.set_yticklabels(t2.Field); ax.set_xscale('log'); ax.set_xticks([10,20,50,100,200]); ax.set_xticklabels(['10','20','50','100','200'])
ax.set_xlabel('Effective number of industries (Hill D1, log scale)'); ax.grid(axis='x',ls=':',lw=.6)
ax.legend(frameon=False,loc='lower center',bbox_to_anchor=(0.45,1.0),ncol=2,fontsize=8)
fig.savefig(f"{F}/Fig1_dispersion_dumbbell.png"); plt.close()

# Fig 2 industry recruitment breadth
t3=pd.read_csv(f"{T}/T3_industry_breadth_all.csv")
fig,ax=plt.subplots(figsize=(6.3,3.6))
ax.scatter(t3.Graduates,t3.D1_fields,s=11,color=OI[0],alpha=.55,linewidths=0,label='Industry with at least 30 graduates')
c=t3[t3.Industry.isin(CATCH)]; ax.scatter(c.Graduates,c.D1_fields,s=40,marker='D',color=OI[3],label='Catch-all category')
lab={'Accounting activities, bookkeeping and auditing, tax consulting':'Accounting','Hospital activities':'Hospitals','Veterinary activities':'Veterinary',
     'Other industries':'Other industries','Central administration':'Central administration','Legal activities':'Legal','Convenience store/minimart':'Convenience stores',
     'Food service in restaurants/food stalls':'Restaurants','Hotels, resorts and apartments':'Hotels'}
pos={'Accounting':(1.6e4,1.5),'Hospitals':(2.2e4,3.2),'Convenience stores':(2.2e4,4.5),'Veterinary':(3e2,3.0),'Legal':(4.5e3,2.7),
     'Other industries':(4.5e4,8.6),'Central administration':(3.0e4,5.75),'Restaurants':(5e3,8.3),'Hotels':(1.9e4,6.75)}
for _,r in t3[t3.Industry.isin(lab)].iterrows():
    L=lab[r.Industry]
    ax.annotate(L,(r.Graduates,r.D1_fields),xytext=pos[L],textcoords='data',fontsize=7,ha='center',
                arrowprops=dict(arrowstyle='-',lw=.5,color='#555',shrinkA=1,shrinkB=3))
med=t3.D1_fields.median(); ax.axhline(med,color='#777',ls='--',lw=.8); ax.text(1.5e5,med+.15,f'Median = {med:.2f}',fontsize=7,color='#555',ha='right')
ax.set_xscale('log'); ax.set_ylim(1,11); ax.set_xlabel('Graduates employed in industry (log scale)'); ax.set_ylabel('Effective number of supplying fields (of 11)')
ax.legend(frameon=False,fontsize=7,loc='upper left'); fig.savefig(f"{F}/Fig2_industry_breadth.png"); plt.close()

# Fig 3 similarity heatmap excl catch-all
S=pd.read_csv(f"{T}/T7b_field_similarity_excl_catchall.csv",index_col=0); D=1-S.values; np.fill_diagonal(D,0)
o=leaves_list(linkage(squareform(D,checks=False),'average')); S=S.iloc[o,o]; V=S.values.copy(); np.fill_diagonal(V,np.nan)
fig,ax=plt.subplots(figsize=(5.6,4.6)); im=ax.imshow(V,cmap='viridis',vmin=.5,vmax=1)
ax.set_xticks(range(11)); ax.set_xticklabels(S.columns,rotation=45,ha='right'); ax.set_yticks(range(11)); ax.set_yticklabels(S.index)
for i in range(11):
    for j in range(11):
        if i!=j: ax.text(j,i,f"{V[i,j]:.2f}",ha='center',va='center',fontsize=6,color='white' if V[i,j]<.8 else 'black')
ax.spines[:].set_visible(False); cb=fig.colorbar(im,ax=ax,fraction=.046); cb.set_label('Destination-profile similarity (1 - JSD)')
fig.savefig(f"{F}/Fig3_field_similarity.png"); plt.close()

# Fig 4 degree
d=pd.read_csv(f"{T}/T2b_dispersion_by_degree.csv"); degs=['Bachelor','Master','Doctorate']
fig,axs=plt.subplots(1,2,figsize=(6.6,3.3),gridspec_kw={'width_ratios':[1.25,1]})
pv=d.pivot(index='Field',columns='Degree',values='CatchAll_share')[degs]
for f,r in pv.iterrows(): axs[0].plot(range(3),r.values,color=G,lw=.9,marker='o',ms=3,zorder=1)
pool=[M['catchall_share_by_degree'][g] for g in degs]
axs[0].plot(range(3),pool,color='black',lw=2.4,marker='s',ms=6,zorder=3,label='All fields pooled')
for f,dy in [('Health & welfare',(0,6)),('Education',(0,-11)),('Engineering',(0,-11))]:
    axs[0].annotate(f,(0,pv.loc[f,'Bachelor']),xytext=(-6,dy[1]/3),textcoords='offset points',ha='right',fontsize=7)
axs[0].plot([],[],color=G,lw=.9,marker='o',ms=3,label='Individual field'); axs[0].legend(frameon=False,fontsize=7,loc='upper left')
axs[0].set_xticks(range(3)); axs[0].set_xticklabels(degs); axs[0].set_xlim(-1.4,2.2); axs[0].set_ylabel('Share in the two catch-all categories'); axs[0].set_ylim(0,1)
axs[0].text(-0.18,1.02,'(a)',transform=axs[0].transAxes,fontweight='bold')
raw=[M['D1_pooled_by_degree'][g] for g in degs]; rar=[M['rarefied_D1_excl_catchall_by_degree'][g] for g in degs]; x=np.arange(3)
axs[1].bar(x-.19,raw,.38,color=OI[0],label='All industries, full sample')
axs[1].bar(x+.19,rar,.38,color='white',edgecolor=OI[3],hatch='///',label=f"Excl. catch-all, rarefied to n = {M['rarefied_D1_excl_catchall_at_n']:,}")
axs[1].set_xticks(x); axs[1].set_xticklabels(degs); axs[1].set_ylabel('Effective number of industries (D1)'); axs[1].set_ylim(0,320)
axs[1].legend(frameon=False,fontsize=6.5,loc='upper left'); axs[1].text(-0.22,1.02,'(b)',transform=axs[1].transAxes,fontweight='bold')
fig.tight_layout(); fig.savefig(f"{F}/Fig4_degree_catchall.png"); plt.close()

# Fig 5 year index with highlights
yr=P.pivot_table(index='fs',columns='year',values='n',aggfunc='sum'); idx=yr.div(yr[2021],axis=0)*100
fig,ax=plt.subplots(figsize=(5.6,3.5)); X=[2021,2022,2023]
hi={'Education':(OI[3],'--','s'),'Health & welfare':(OI[0],'-.','^'),'Social sciences':(OI[2],':','D')}
for f,r in idx.iterrows():
    if f not in hi: ax.plot(X,r.values,color=G,lw=.9,zorder=1)
for f,(c,l,m) in hi.items(): ax.plot(X,idx.loc[f].values,color=c,ls=l,marker=m,lw=1.6,ms=5,label=f,zorder=2)
tot=P.groupby('year').n.sum(); ax.plot(X,(tot/tot[2021]*100).values,color='black',lw=2.4,marker='o',ms=5,label='All fields pooled',zorder=3)
ax.plot([],[],color=G,lw=.9,label='Other fields'); ax.set_xticks(X); ax.set_ylabel('Graduates recorded (index, 2021 = 100)'); ax.axhline(100,color='#ccc',lw=.7,zorder=0)
ax.legend(frameon=False,fontsize=7,bbox_to_anchor=(1.01,1),loc='upper left'); fig.savefig(f"{F}/Fig5_year_index.png"); plt.close()
print('ok')
