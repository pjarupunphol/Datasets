"""Step 4: format manuscript tables from frozen outputs. Usage: python -I tables_fmt.py out"""
import sys, json, numpy as np, pandas as pd
exec(open('common.py').read())
out=sys.argv[1]; T=f"{out}/tables"; M=json.load(open(f"{out}/result_manifest.json")); L=json.load(open(f"{out}/cleaning_log.json"))
P=load(out); CATCH=['Other industries','Central administration']; N=P.n.sum()
f0=lambda x:f"{int(round(x)):,}"; f1=lambda x:f"{x:.1f}"; f2=lambda x:f"{x:.2f}"; f3=lambda x:f"{x:.3f}"; pc=lambda x:f"{100*x:.1f}"
TB={}
# Table 1 audit
TB['T1']={'head':['Audit step','Finding','Rows','Graduates','Treatment'],'rows':[
 ['A0 Raw workbook','Five columns, no missing values','30,259','819,098','Preserved unchanged'],
 ['A1 Subtotal leakage','Field-label strings in the industry column of the Business, administration and law block; each equals another field’s year-by-degree total (18/18)','18','135,996','Removed'],
 ['A2 Duplicate keys','Field x industry x year x degree keys occurring twice, all within the Business, administration and law block; 276 pairs share an identical count','6,196 (3,098 pairs)','n.a.','Summed (primary); two alternatives in Table 6'],
 ['A3 Label hygiene','Trailing spaces and missing spaces after commas in labels','9','n.a.','Normalised'],
 ['A4 Catch-all categories','"Other industries" and "Central administration"',f0(P.industry.isin(CATCH).sum()),f0(P[P.industry.isin(CATCH)].n.sum()),'Retained; sensitivity analyses'],
 ['A5 Temporal coverage','2023 total 28.5% below 2022; field-level change from -51.7% to -15.5%','9,548 (raw)','184,093','Retained; 2021–2022 sensitivity'],
 ['Analytical dataset','11 fields x 953 industries x 3 years x 3 degree levels',f0(M['N_cells']),f0(N),'Frozen for analysis']]}
# Table 2 descriptives
t1=pd.read_csv(f"{T}/T1_descriptives.csv",index_col=0)
rows=[]
for f,r in t1.iterrows():
    rows.append([f if f!='Total' else 'All fields',f0(r.Graduates),f1(r['Share_%']),f0(r.Bachelor),f0(r.Master),f0(r.Doctorate),f0(r['2021']),f0(r['2022']),f0(r['2023']),f1(r['Change_2022_2023_%']),f0(r.Industries_entered)])
TB['T2']={'head':['Field of study','Graduates','Share (%)','Bachelor','Master','Doctorate','2021','2022','2023','Change 2022–2023 (%)','Industries entered'],'rows':rows}
# Table 3 dispersion
t2=pd.read_csv(f"{T}/T2_field_dispersion.csv").sort_values('D1')
TB['T3']={'head':['Field of study','D1 [95% CI]','D1 range across years','D2','CR5 (%)','Catch-all share (%)','D1 excl. catch-all','Largest non-catch-all industry (share, %)'],
 'rows':[[r.Field,f"{r.D1:.1f} [{r.D1_lo:.1f}, {r.D1_hi:.1f}]",f"{r.D1_year_min:.1f}–{r.D1_year_max:.1f}",f1(r.D2),pc(r.CR5),pc(r.CatchAll_share),f1(r.D1_excl_catchall),f"{r.Top_noncatch} ({100*r.Top_noncatch_share:.1f})"] for _,r in t2.iterrows()]}
# Table 4 signature industries (non catch-all, n>=30, LQ>=2): top two by graduates
FI=P.groupby(['fs','industry']).n.sum().unstack(fill_value=0); Nf=FI.sum(axis=1); Ni=FI.sum(axis=0); LQ=FI.div(Ni,axis=1).div(Nf/N,axis=0)
rows=[]; sigx={}
for f in t2.Field:
    s=pd.DataFrame({'n':FI.loc[f],'LQ':LQ.loc[f]}).drop(CATCH); s=s[(s.n>=30)&(s.LQ>=2)].sort_values('n',ascending=False)
    sigx[f]=s.n.sum()/Nf[f]
    for k,(i,r) in enumerate(s.head(2).iterrows()):
        rows.append([f if k==0 else '',(i[0].upper()+i[1:]).rstrip('.'),f0(r.n),pc(r.n/Nf[f]),f1(r.LQ),pc(sigx[f]) if k==0 else ''])
TB['T4']={'head':['Field of study','Signature industry','Graduates','Share of field (%)','LQ','All signature industries (% of field)'],'rows':rows}
M['signature_share_excl_catchall']=sigx
# Table 5 identifiability
t5=pd.read_csv(f"{T}/T5_identifiability.csv",index_col=0)
lab={'pooled':'Industry label (all degrees, graduate-weighted)','Bachelor':'  Bachelor only','Master':'  Master only','Doctorate':'  Doctorate only',
 'excl_catchall':'Industry label, catch-all categories excluded','industry_plus_degree':'Industry label + degree level','row_weighted':'Industry label, cell-weighted (each row counts once)'}
rows=[[lab[k],f3(r.U),pc(r.majority_acc),pc(r.bayes_acc),f"{100*(r.bayes_acc-r.majority_acc):.1f}",f3(r.bayes_macroF1)] for k,r in t5.iterrows()]
tc=M['text_clf']
rows.append(['Empirical TF-IDF classifier, unseen labels (graduate-weighted)','n.a.','n.a.',pc(tc['acc_grad_weighted']),'n.a.',f3(tc['macroF1_grad_weighted'])])
rows.append(['Empirical TF-IDF classifier, unseen labels (cell-weighted)','n.a.','n.a.',pc(tc['acc_row']),'n.a.',f3(tc['macroF1_row'])])
TB['T5']={'head':['Information available to the predictor','U(F | I)','Majority accuracy (%)','Bayes-optimal accuracy (%)','Gain (pp)','Macro-F1 of decision rule'],'rows':rows}
# Table 6 robustness
t8=pd.read_csv(f"{T}/T8_robustness.csv")
vl={'primary':'Sum duplicate pairs (primary)','dedup_then_sum':'Drop identical pairs, then sum','max_of_pair':'Keep larger member of each pair'}
rows=[[vl[r.Variant],r.Years,f0(r.Graduates),f3(r.U),pc(r.Bayes_acc),f3(r.rho_D1_vs_primary),f1(r['D1_Health & welfare']),f1(r['D1_Engineering'])] for _,r in t8.iterrows()]
TB['T6']={'head':['Duplicate-key rule','Years','Graduates','U(F | I)','Bayes-optimal accuracy (%)','Spearman ρ of field D1 ranks vs primary','D1 Health & welfare','D1 Engineering'],'rows':rows}
json.dump(TB,open(f"{out}/tables_fmt.json",'w'),indent=1,ensure_ascii=False)
json.dump(M,open(f"{out}/result_manifest.json",'w'),indent=2,default=float)
for k,v in TB.items(): print(k, len(v['rows']), v['rows'][:2])
print(pd.DataFrame(TB['T4']['rows'],columns=TB['T4']['head']).to_string())
