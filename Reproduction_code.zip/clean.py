"""Step 1: build the frozen analysis dataset from the raw workbook.
Usage: python -I clean.py <raw.xlsx> <outdir>"""
import sys, json, pandas as pd
raw, out = sys.argv[1], sys.argv[2]
log = {}
df = pd.read_excel(raw); df.columns = ['field','industry','year_be','degree','n']
log['raw_rows'] = len(df); log['raw_graduates'] = int(df.n.sum())
for c in ['field','industry','degree']: df[c] = df[c].str.strip().str.replace(r'\s+',' ',regex=True)
# harmonise field label punctuation (missing space after comma in source)
df['field'] = df.field.str.replace(r',(?=\S)', ', ', regex=True)
df['industry_key'] = df.industry
# 1. leaked subtotal rows: field-label strings in the industry column within the Business block
fields = set(df.field)
leak = df.industry.str.replace(r',(?=\S)', ', ', regex=True).isin(fields)
log['leaked_subtotal_rows'] = int(leak.sum()); log['leaked_subtotal_graduates'] = int(df.loc[leak,'n'].sum())
log['leaked_rows_fields'] = sorted(df.loc[leak,'field'].unique().tolist())
# verify they equal field totals
chk = []
for _, r in df[leak].iterrows():
    tgt = r.industry.replace(',', ', ').replace('  ',' ')
    tot = df[(df.field==tgt)&(df.year_be==r.year_be)&(df.degree==r.degree)&~leak].n.sum()
    chk.append(int(tot)==int(r.n))
log['leaked_rows_equal_field_totals'] = f"{sum(chk)}/{len(chk)}"
d = df[~leak].copy()
log['exact_duplicate_rows_after_leak_removal'] = int(d.duplicated(['field','industry','year_be','degree','n']).sum())
key = ['field','industry','year_be','degree']
log['duplicate_key_groups'] = int(d.duplicated(key, keep=False).sum()//2)
def agg(x, how):
    if how=='sum': return x.groupby(key, as_index=False).n.sum()
    if how=='max': return x.groupby(key, as_index=False).n.max()
    if how=='dedup_sum': return x.drop_duplicates(key+['n']).groupby(key, as_index=False).n.sum()
variants = {'primary': agg(d,'sum'), 'dedup_then_sum': agg(d,'dedup_sum'), 'max_of_pair': agg(d,'max')}
for k, v in variants.items():
    v['year'] = v.year_be - 543
    v.to_csv(f"{out}/data_{k}.csv", index=False)
    log[f'{k}_rows'] = len(v); log[f'{k}_graduates'] = int(v.n.sum())
p = variants['primary']
log['n_fields']=p.field.nunique(); log['n_industries']=p.industry.nunique(); log['years']=sorted(p.year.unique().tolist())
json.dump(log, open(f"{out}/cleaning_log.json",'w'), indent=2)
print(json.dumps(log, indent=2))
