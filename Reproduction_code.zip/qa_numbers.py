"""QA: check every claimed number in manuscript text against frozen results. Usage: python -I qa_numbers.py out ms.txt"""
import sys, json, re, pandas as pd, numpy as np
out, ms = sys.argv[1], open(sys.argv[2]).read().replace('\n',' ')
M=json.load(open(f"{out}/result_manifest.json")); I=M['identifiability']; T=f"{out}/tables"
t2=pd.read_csv(f"{T}/T2_field_dispersion.csv").set_index('Field'); t3=pd.read_csv(f"{T}/T3_industry_breadth_all.csv")
st=pd.read_csv(f"{T}/T6_stability.csv"); d1y=pd.read_csv(f"{T}/T6b_D1_by_year.csv",index_col=0)
P=pd.read_csv(f"{out}/data_primary.csv"); yr=P.groupby(['field','year_be']).n.sum().unstack()
checks={
 '683,102':M['N_graduates'],'27,143':M['N_cells'],'953':M['N_industries'],'19.9%':round(M['leak_inflation_pct_of_clean'],1),
 '50.6%':round(100*M['business_share_raw_vs_clean'][0],1),'40.8%':round(100*M['business_share_raw_vs_clean'][1],1),
 '14.6':round(t2.loc['Health & welfare','D1'],1),'158.2':round(t2.loc['Engineering','D1'],1),'5.2 effective':round(np.median(t3.D1_fields),1),
 '10.4%':round(100*I['pooled']['U'],1),'42.4%':round(100*I['pooled']['bayes_acc'],1),'40.8% for always':round(100*I['pooled']['majority_acc'],1),
 '25.9%':round(100*M['CatchAll_overall'],1),'23.9%':round(100*M['catchall_share_by_degree']['Bachelor'],1),'66.2%':round(100*M['catchall_share_by_degree']['Doctorate'],1),
 '42.5%':round(100*M['catchall_share_by_degree']['Master'],1),'8.7%, 26.6% and 43.7%':[round(100*M['central_admin_share_by_degree'][k],1) for k in ['Bachelor','Master','Doctorate']],
 '75.1%':round(100*t2.loc['Health & welfare','CR5'],1),'27.2%':round(100*t2.loc['Engineering','CR5'],1),'3.5%':round(M['D1_boot_halfwidth_pct_max'],2),
 'ρ = 0.91':round(M['rank_corr_D1_vs_D2'],2),'53.8%':round(100*t2.loc['Health & welfare','CatchAll_share'],1),'45.2%':round(100*t2.loc['Education','CatchAll_share'],1),
 '43.1':round(t2.loc['Education','D1'],1),'163.6':round(t2.loc['Education','D1_excl_catchall'],1),'254.6':round(t2.loc['Natural sciences','D1_excl_catchall'],1),
 '0.78':round(M['rank_corr_D1_vs_D1_excl_catchall'],2),'1.0% of Education':round(100*M['education_field_in_education_industries'],1),'31.0%':round(100*M['education_field_central_admin'],1),
 '384':M['presence_all11'],'696':M['industries_ge30'],'55.2%':round(100*M['industries_all11_fields_share'],1),'5.18':round(M['industry_D1_quartiles'][1],2),
 '4.22–6.09':[M['industry_D1_quartiles'][0],M['industry_D1_quartiles'][2]],'227':M['industries_dominant_ge50'],'32.6%':round(100*M['industries_dominant_ge50']/M['industries_ge30'],1),
 '91.9%':round(100*t3.Dominant_share.max(),1),'135.3 to 64.7 and 17.9':[round(M['D1_pooled_by_degree'][k],1) for k in ['Bachelor','Master','Doctorate']],
 '218.2, 235.0 and 216.8':[round(M['rarefied_D1_excl_catchall_by_degree'][k],1) for k in ['Bachelor','Master','Doctorate']],'2,915':M['rarefied_D1_excl_catchall_at_n'],
 '1.5 percentage':round(100*(I['pooled']['bayes_acc']-I['pooled']['majority_acc']),1),'0.2 percentage':round(100*(I['Master']['bayes_acc']-I['Master']['majority_acc']),1),
 '0.056':round(I['row_weighted']['U'],3),'18.9%':round(100*I['row_weighted']['bayes_acc'],1),'15.4%':round(100*M['text_clf']['acc_grad_weighted'],1),'12.7%':round(100*M['text_clf']['acc_row'],1),
 '0.117':round(M['text_clf']['macroF1_grad_weighted'],3),'0.095':round(M['text_clf']['macroF1_row'],3),
 '157.7':round(100*yr.loc['Education',2565]/yr.loc['Education',2564],1),'76.1':round(100*yr.loc['Education',2566]/yr.loc['Education',2564],1),
 '86.5':round(100*yr.loc['Health and welfare',2566]/yr.loc['Health and welfare',2564],1),'0.026':M['JSD_median_by_pair']['2021-2022'],'0.033':round(M['JSD_median_by_pair']['2022-2023'],3),
 '0.041':round(M['JSD_median_by_pair']['2021-2023'],3),'1.4 to 1.8':[M['JSD_ratio_median_by_pair'][k] for k in ['2021-2022','2022-2023','2021-2023']],'0.080':round(M['JSD_max'],3),
 'ρ = 0.87':round(M['D1_rank_corr_2021_2023'],2),'0.99 between':round(M['D1_rank_corr_2022_2023'],2),'0.104 to 0.109':[round(x,3) for x in M['robustness_U_range']],
 '0.991':round(M['robustness_rho_min'],3),'35.6%':round(100*M['robustness_bayes_range'][0],1),'90.8%':round(100*M['degree_totals']['Bachelor']/M['N_graduates'],1),
 '28.5%':round(100*(1-M['year_totals']['2023']/M['year_totals']['2022']),1),'57.7%':round(100*(yr.loc['Education',2565]/yr.loc['Education',2564]-1),1),
 'median of 722':'(raw gap median, verified in audit step)','33.0% for Services':round(100*M['signature_share_excl_catchall']['Services'],1),
 '31.7% for Engineering':round(100*M['signature_share_excl_catchall']['Engineering'],1),'5.8% for Social':round(100*M['signature_share_excl_catchall']['Social sciences'],1),
 '2.5% for Business':round(100*M['signature_share_excl_catchall']['Business, admin. & law'],1),
}
for k,v in checks.items(): print(('OK ' if k in ms else 'MISSING ')+f"{k!r:35} -> computed {v}")
