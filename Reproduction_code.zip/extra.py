"""Step 2b: supplementary computations. Usage: python -I extra.py out"""
import sys, json, numpy as np, pandas as pd
out=sys.argv[1]; T=f"{out}/tables"; rng=np.random.default_rng(7)
exec(open('common.py').read())
P=load(out); CATCH=['Other industries','Central administration']; M=json.load(open(f"{out}/result_manifest.json"))
# basic-bootstrap 95% interval for D1 (corrects plug-in downward bias)
t2=pd.read_csv(f"{T}/T2_field_dispersion.csv"); FI=P.groupby(['fs','industry']).n.sum().unstack(fill_value=0)
lo=[];hi=[]
for f in t2.Field:
    c=FI.loc[f][lambda s:s>0].values; th=hill(c)[0]
    bs=[hill(r)[0] for r in rng.multinomial(c.sum(),c/c.sum(),size=1000)]
    q=np.percentile(bs,[2.5,97.5]); lo.append(2*th-q[1]); hi.append(2*th-q[0])
t2['D1_lo']=lo; t2['D1_hi']=hi
t2['D1_halfwidth_pct']=(t2.D1_hi-t2.D1_lo)/2/t2.D1*100
sig=pd.read_csv(f"{T}/T4b_signature_share.csv",index_col=0).iloc[:,0]; t2['Signature_share']=t2.Field.map(sig)
d1y=pd.read_csv(f"{T}/T6b_D1_by_year.csv",index_col=0); t2['D1_year_min']=t2.Field.map(d1y.min(1)); t2['D1_year_max']=t2.Field.map(d1y.max(1))
t2.to_csv(f"{T}/T2_field_dispersion.csv",index=False); M['D1_boot_halfwidth_pct_max']=float(t2.D1_halfwidth_pct.max())
# rarefied D1 by degree, excluding catch-all, at doctorate sample size
X=P[~P.industry.isin(CATCH)]; nd=int(X[X.degree=='Doctorate'].n.sum()); r={}
for dg in ['Bachelor','Master','Doctorate']:
    c=X[X.degree==dg].groupby('industry').n.sum().values
    r[dg]=float(np.mean([hill(rng.multivariate_hypergeometric(c,nd))[0] for _ in range(200)])) if dg!='Doctorate' else hill(c)[0]
M['rarefied_D1_excl_catchall_at_n']=nd; M['rarefied_D1_excl_catchall_by_degree']=r
M['catchall_share_by_degree']=(P[P.industry.isin(CATCH)].groupby('degree').n.sum()/P.groupby('degree').n.sum()).round(3).to_dict()
M['central_admin_share_by_degree']=(P[P.industry=='Central administration'].groupby('degree').n.sum()/P.groupby('degree').n.sum()).round(3).to_dict()
# education-type industries share for Education field
edu=P.industry.str.contains('educat|school|teach|tutor',case=False)
E=P[P.fs=='Education']; M['education_field_in_education_industries']=float(E[edu[E.index]].n.sum()/E.n.sum())
M['education_field_central_admin']=float(E[E.industry=='Central administration'].n.sum()/E.n.sum())
# specialised industries with >=200 graduates
t3=pd.read_csv(f"{T}/T3_industry_breadth_all.csv"); big=t3[t3.Graduates>=200]
M['industries_ge200']=len(big); M['industries_ge200_median_dominant_share']=float(big.Dominant_share.median())
big.sort_values('Dominant_share',ascending=False).head(10).to_csv(f"{T}/T5_specialised_ge200.csv",index=False)
M['industries_ge30_median_dominant_share']=float(t3.Dominant_share.median())
# leaked-row impact summary
M['leak_inflation_pct_of_clean']=135996/M['N_graduates']*100
M['business_share_raw_vs_clean']=[414809/819098, float(P[P.fs.str.startswith('Business')].n.sum()/M['N_graduates'])]
json.dump(M,open(f"{out}/result_manifest.json",'w'),indent=2,default=float)
for k in ['D1_boot_halfwidth_pct_max','rarefied_D1_excl_catchall_at_n','rarefied_D1_excl_catchall_by_degree','catchall_share_by_degree','central_admin_share_by_degree','education_field_in_education_industries','education_field_central_admin','industries_ge200','industries_ge200_median_dominant_share','industries_ge30_median_dominant_share','leak_inflation_pct_of_clean','business_share_raw_vs_clean']: print(k,M[k])
print(pd.read_csv(f"{T}/T5_specialised_ge200.csv").round(3).to_string())
