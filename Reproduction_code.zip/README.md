# Reproduction scripts

Run from this folder with Python 3.13 (pandas 3.0, NumPy 2.5, SciPy 1.18, scikit-learn 1.9, matplotlib 3.11):

    mkdir -p out/tables out/figs
    python -I clean.py Corrected_Graduate_Data_En.xlsx out   # audit + reconciliation (Table 1)
    python -I analyze.py out                                 # primary analysis, result manifest
    python -I extra.py out                                   # bootstrap intervals, rarefaction, extras
    python -I figs.py out                                    # Figures 1-5
    python -I tables_fmt.py out                              # manuscript tables
    python -I supp.py out                                    # supplementary workbook
    python -I qa_numbers.py out manuscript.txt               # check numbers quoted in a plain-text export of the manuscript

All random seeds are fixed. `out/result_manifest.json` holds every quoted statistic.
