short = {'Agriculture, forestry, fisheries and veterinary':'Agriculture','Arts and humanities':'Arts & humanities',
 'Business, administration and law':'Business, admin. & law','Education':'Education',
 'Engineering, manufacturing and construction':'Engineering','Health and welfare':'Health & welfare','ICTs':'ICTs',
 'Natural sciences, mathematics and statistics':'Natural sciences','Services':'Services',
 'Social sciences, journalism and information':'Social sciences','Tourism, Hospitality, Travel, Services, Recreation':'Tourism & hospitality'}
def load(out):
    P=pd.read_csv(f"{out}/data_primary.csv"); P['fs']=P.field.map(short); return P
def hill(c):
    c=np.asarray(c,float); p=c[c>0]/c.sum(); H=-(p*np.log(p)).sum(); return np.exp(H),1/(p**2).sum(),H
