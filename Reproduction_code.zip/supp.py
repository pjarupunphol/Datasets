"""Step 5: supplementary workbook. Usage: python -I supp.py out"""
import sys, json, pandas as pd
out=sys.argv[1]; T=f"{out}/tables"
L=json.load(open(f"{out}/cleaning_log.json"))
refs=[
('Abdulla 2025','IDEAS record: Education Economics 33(4) 595-612; DOI confirmed; abstract read','OK'),
('Bae & Kim 2023','IDEAS record: Empirical Economics 64(2) 931-958; DOI confirmed; abstract read','OK'),
('Cassidy & Gaulke 2024','IDEAS record: Economic Inquiry 62(2) 607-632; DOI confirmed; abstract read','OK'),
('Chao et al. 2023','St Andrews repository + CRAN citation: Ecological Monographs 93(4) e1588; DOI 10.1002/ecm.1588','OK'),
('Coraggio et al. 2026','Verified by author: Labour Economics 102, Article 102955; DOI 10.1016/j.labeco.2026.102955','OK'),
('Eggenberger et al. 2022','IDEAS record: Labour Economics 78; DOI 10.1016/j.labeco.2022.102187','OK'),
('Hill 1973','Classic; title and venue confirmed','OK'),
('Ishida et al. 2023','ICLR 2023 page confirms authors, title, venue','OK'),
('Jackson & Rowe 2023','Crossref: Studies in Higher Education 48(3) 490-506','OK'),
('Javadian Sabet et al. 2024','Crossref: Scientific Data 11(1), Article 1086','OK'),
('Jiang 2024','IDEAS record: Empirical Economics 67(3) 1275-1301; abstract read','OK'),
('Jost 2006','Classic; title and venue confirmed','OK'),
('Kapoor & Narayanan 2023','Crossref: Patterns 4(9) Article 100804','OK'),
('Labussiere & Bol 2026','Sociological Science page: 13, 362-407; DOI 10.15195/v13.a16','OK'),
('Langezaal et al. 2023','Verified by author: Communications Medicine 3, Article 160','OK'),
('Lee 2024','IDEAS record: Journal of Asian Economics 94; DOI 10.1016/j.asieco.2024.101781','OK'),
('Leighton & Speer 2020','Verified by author','OK'),
('Lin 1991','IEEE document 61115 confirmed','OK'),
('Lohberger & Braun 2022','Verified in earlier project citation table','OK'),
('Ma et al. 2025','ACL Anthology record: NAACL 2025 SRW pp. 392-399; DOI confirmed','OK'),
('Marczuk 2024','Crossref: Journal for Labour Market Research 58(1) Article 19','OK'),
('Minaya et al. 2024','IDEAS record: Research in Higher Education 65(5) 775-793; DOI confirmed','OK'),
('Ministry of Commerce 2009','Provided by author (TSIC 2009 PDF)','OK'),
('OECD 2025','OECD page: OECD Skills Strategy Thailand; DOI not shown','Optional: add DOI'),
('Onozuka 2022','IDEAS record: Journal of Labor Research 43(1) 24-64; DOI confirmed','OK'),
('Pivovarova & Powers 2022','Verified in earlier project citation table','OK'),
('Promnuchanont et al. 2026','Journal page: Science & Technology Asia 31(1) 145-158; no DOI shown','OK'),
('Scandurra et al. 2024','Crossref: Studies in Higher Education 49(8) 1381-1396','OK'),
('Sellami et al. 2018','Verified by author','OK'),
('Senkrua 2022','Journal page: Review of Economics and Finance 20, 816-825; DOI confirmed','OK'),
('Serikbayeva & Abdulla 2022','IDEAS record: Social Indicators Research 163(2) 723-752; DOI confirmed','OK'),
('Stellian et al. 2024','Provided by author','OK'),
('Tran et al. 2026','SAGE page: Evaluation Review 50(4) 577-609; DOI confirmed','OK'),
('UNESCO UIS 2014','ISCED-F 2013 standard','OK'),
('Varona Cervantes & Cooper 2022','IDEAS record: EER 148 (2022)','OK'),
('Weiss et al. 2024','IDEAS record: Contemporary Economic Policy 42(2) 278-304; DOI confirmed','OK'),
('Whang et al. 2023','KAIST repository: VLDB Journal 32(4) 791-813; DOI confirmed','OK'),
('Zha et al. 2025','Verified by author: ACM Computing Surveys 57(5) 1-42; DOI 10.1145/3711118','OK'),
('Zhang et al. 2023','Verified by author and ACL Anthology: pp. 11871-11890; DOI confirmed','OK')]
with pd.ExcelWriter(f"{out}/Supplementary_Tables.xlsx") as W:
    pd.DataFrame({'About':[
     'Supplementary tables for: Field of Study, Industry of Employment, and the Limits of Prediction (Thai graduate destinations, 2021-2023).',
     'All values computed from the reconciled dataset (primary rule: duplicate-key pairs summed; 18 subtotal rows removed) unless the sheet states otherwise.',
     'D1 = effective number (exp Shannon entropy); D2 = inverse Simpson; JSD = Jensen-Shannon divergence (bits); LQ = location quotient; U = uncertainty coefficient.']}).to_excel(W,sheet_name='README',index=False)
    pd.Series(L).rename('value').to_frame().to_excel(W,sheet_name='S1_cleaning_log')
    for name,f in [('S2_field_dispersion','T2_field_dispersion'),('S3_dispersion_by_degree','T2b_dispersion_by_degree'),('S4_industry_intake','T3_industry_breadth_all'),
                   ('S6_identifiability','T5_identifiability'),('S7_stability_JSD','T6_stability'),('S8_D1_by_year','T6b_D1_by_year'),
                   ('S9a_similarity_all','T7_field_similarity'),('S9b_similarity_excl_catchall','T7b_field_similarity_excl_catchall'),('S10_robustness','T8_robustness')]:
        pd.read_csv(f"{T}/{f}.csv").round(4).to_excel(W,sheet_name=name,index=False)
    # S5 all signature industries
    exec(open('common.py').read(),globals()); import numpy as np
    P=load(out); CATCH=['Other industries','Central administration']; N=P.n.sum(); FI=P.groupby(['fs','industry']).n.sum().unstack(fill_value=0)
    Nf=FI.sum(axis=1); Ni=FI.sum(axis=0); LQ=FI.div(Ni,axis=1).div(Nf/N,axis=0); rows=[]
    for f in FI.index:
        s=pd.DataFrame({'Graduates':FI.loc[f],'LQ':LQ.loc[f]}).drop(CATCH); s=s[(s.Graduates>=30)&(s.LQ>=2)].sort_values('Graduates',ascending=False)
        s['Field']=f; s['Share_of_field']=s.Graduates/Nf[f]; rows.append(s.reset_index().rename(columns={'index':'Industry'}))
    pd.concat(rows)[['Field','industry','Graduates','Share_of_field','LQ']].rename(columns={'industry':'Industry'}).round(4).to_excel(W,sheet_name='S5_signature_industries',index=False)
    pd.DataFrame(refs,columns=['Reference','Verification evidence','Action before submission']).to_excel(W,sheet_name='S11_reference_check',index=False)
print('ok')
